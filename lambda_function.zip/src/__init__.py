"""
Email parser system for franchise resales lead processing.
"""

__version__ = "2.0.0"
__author__ = "Franchise Resales Team"