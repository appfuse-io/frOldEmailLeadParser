"""
Lambda handlers and event processing.
"""

from .lambda_handler import lambda_handler

__all__ = [
    'lambda_handler'
]